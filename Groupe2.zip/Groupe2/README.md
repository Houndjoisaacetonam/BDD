# Benin Bank — API de Détection de Fraude

Système intelligent de détection de fraude bancaire basé sur **XGBoost**, avec une API REST (FastAPI) et une interface utilisateur web.

## Structure du projet

```
Groupe2/
├── api/
│   ├── __init__.py
│   ├── main.py          # Application FastAPI
│   ├── schemas.py       # Modèles Pydantic (validation)
│   └── model_loader.py  # Chargement du modèle et prédictions
├── models/
│   ├── xgb_model.json   # Modèle XGBoost (format natif)
│   └── xgb_model.pkl    # Modèle XGBoost (format pickle)
├── ui/
│   ├── index.html       # Interface utilisateur
│   └── static/
│       ├── css/style.css
│       └── js/app.js
├── data/                # Données (à placer ici)
├── notebooks/           # Notebooks Jupyter
├── requirements.txt
├── Dockerfile
└── docker-compose.yml
```

## Lancement rapide (local)

```bash
# 1. Activer l'environnement virtuel
source /home/rachidi/Data_science/.venv/bin/activate

# 2. Installer les dépendances (si nécessaire)
pip install -r requirements.txt

# 3. Lancer l'API depuis le dossier Groupe2/
cd Groupe2
uvicorn api.main:app --reload --host 0.0.0.0 --port 8000
```

Accéder à :
- **Interface UI** : http://localhost:8000
- **Documentation API** : http://localhost:8000/api/docs
- **Santé** : http://localhost:8000/api/health

## Lancement avec Docker

```bash
cd Groupe2
docker-compose up --build
```

## Endpoints API

| Méthode | Route | Description |
|---------|-------|-------------|
| GET | `/api/health` | Vérifie l'état de l'API |
| GET | `/api/model-info` | Informations sur le modèle |
| POST | `/api/predict` | Prédit une transaction |
| POST | `/api/predict/batch` | Prédit plusieurs transactions (max 500) |

## Exemple de requête

```bash
curl -X POST http://localhost:8000/api/predict \
  -H "Content-Type: application/json" \
  -d '{
    "Time": 406, "Amount": 2125.87,
    "V1": -2.31, "V2": 1.95, "V3": -1.61, "V4": 3.99,
    "V5": -0.52, "V6": -1.43, "V7": -2.54, "V8": 1.39,
    "V9": -2.77, "V10": -2.77, "V11": 3.20, "V12": -2.90,
    "V13": -0.60, "V14": -4.29, "V15": 0.39, "V16": -1.14,
    "V17": -2.83, "V18": -0.02, "V19": 0.42, "V20": 0.36,
    "V21": 0.74, "V22": -0.66, "V23": -0.14, "V24": 0.31,
    "V25": 0.02, "V26": 0.24, "V27": 0.52, "V28": 0.24
  }'
```

## Modèle

- **Algorithme** : XGBoost Classifier (1000 arbres)
- **Features** : 30 (Time, V1–V28, Amount)
- **Dataset** : [Credit Card Fraud Detection — Kaggle](https://www.kaggle.com/datasets/mlg-ulb/creditcardfraud)
- **Seuil de décision** : 50% de probabilité de fraude
