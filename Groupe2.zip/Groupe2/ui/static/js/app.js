/* Données d'exemple : transaction normale et transaction frauduleuse */
const SAMPLE_LEGIT = {
  Time: 0, Amount: 149.62,
  V1: -1.3598, V2: -0.0728, V3: 2.5363, V4: 1.3781, V5: -0.3382,
  V6: 0.4624, V7: 0.2396, V8: 0.0987, V9: 0.3638, V10: 0.0908,
  V11: -0.5516, V12: -0.6178, V13: -0.9913, V14: -0.3114, V15: 1.4682,
  V16: -0.4704, V17: 0.2076, V18: 0.0258, V19: 0.4040, V20: 0.2514,
  V21: -0.0183, V22: 0.2778, V23: -0.1104, V24: 0.0669, V25: 0.1285,
  V26: -0.1891, V27: 0.1336, V28: -0.0211,
};

const SAMPLE_FRAUD = {
  Time: 406, Amount: 2125.87,
  V1: -2.3122, V2: 1.9519, V3: -1.6098, V4: 3.9979, V5: -0.5220,
  V6: -1.4265, V7: -2.5374, V8: 1.3918, V9: -2.7700, V10: -2.7722,
  V11: 3.2020, V12: -2.8998, V13: -0.5955, V14: -4.2895, V15: 0.3898,
  V16: -1.1409, V17: -2.8305, V18: -0.0168, V19: 0.4163, V20: 0.3599,
  V21: 0.7393, V22: -0.6566, V23: -0.1422, V24: 0.3135, V25: 0.0187,
  V26: 0.2429, V27: 0.5232, V28: 0.2424,
};

const FEATURE_NAMES = [
  "Time","V1","V2","V3","V4","V5","V6","V7","V8","V9",
  "V10","V11","V12","V13","V14","V15","V16","V17","V18",
  "V19","V20","V21","V22","V23","V24","V25","V26","V27","V28","Amount"
];

// ─── Utilitaires DOM ─────────────────────────────────────────────────────────
const $ = (id) => document.getElementById(id);
const setVal = (id, v) => { const el = $(id); if (el) el.value = v; };

// ─── Remplit le formulaire ────────────────────────────────────────────────────
function fillForm(data) {
  Object.entries(data).forEach(([k, v]) => setVal("field-" + k, v));
}

function resetForm() {
  FEATURE_NAMES.forEach(f => setVal("field-" + f, ""));
  setVal("field-Time", "");
  setVal("field-Amount", "");
  hideResult();
  hideAlert();
}

// ─── Gestion du collapse PCA ─────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", () => {
  const toggle = $("pca-toggle");
  const content = $("pca-content");
  if (toggle && content) {
    toggle.addEventListener("click", () => {
      toggle.classList.toggle("open");
      content.classList.toggle("open");
    });
  }

  // Vérifier santé de l'API
  checkApiHealth();

  // Boutons d'exemples
  $("btn-sample-legit").addEventListener("click", () => {
    fillForm(SAMPLE_LEGIT);
    if (content) { toggle.classList.add("open"); content.classList.add("open"); }
  });
  $("btn-sample-fraud").addEventListener("click", () => {
    fillForm(SAMPLE_FRAUD);
    if (content) { toggle.classList.add("open"); content.classList.add("open"); }
  });

  // Bouton reset
  $("btn-reset").addEventListener("click", resetForm);

  // Formulaire
  $("fraud-form").addEventListener("submit", handleSubmit);
});

// ─── Santé API ────────────────────────────────────────────────────────────────
async function checkApiHealth() {
  try {
    const res = await fetch("/api/health");
    const data = await res.json();
    const dot = document.querySelector(".status-dot");
    const lbl = $("api-status-label");
    if (data.status === "ok" && data.model_loaded) {
      if (dot) dot.style.background = "#2dc653";
      if (lbl) lbl.textContent = "API opérationnelle";
    } else {
      if (dot) dot.style.background = "#f4a261";
      if (lbl) lbl.textContent = "Modèle non chargé";
    }
  } catch {
    const dot = document.querySelector(".status-dot");
    const lbl = $("api-status-label");
    if (dot) dot.style.background = "#e63946";
    if (lbl) lbl.textContent = "API hors ligne";
  }
}

// ─── Lecture du formulaire ────────────────────────────────────────────────────
function readForm() {
  const data = {};
  FEATURE_NAMES.forEach(f => {
    const el = $("field-" + f);
    const v = el ? parseFloat(el.value) : NaN;
    if (isNaN(v)) throw new Error(`Valeur manquante ou invalide pour le champ : ${f}`);
    data[f] = v;
  });
  return data;
}

// ─── Soumission ───────────────────────────────────────────────────────────────
async function handleSubmit(e) {
  e.preventDefault();
  hideAlert();

  let payload;
  try {
    payload = readForm();
  } catch (err) {
    showAlert(err.message, "error");
    return;
  }

  const btn = $("btn-predict");
  btn.classList.add("loading");
  btn.querySelector(".btn-text").textContent = "Analyse en cours…";

  try {
    const res = await fetch("/api/predict", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.detail || "Erreur serveur");
    }
    const result = await res.json();
    renderResult(result);
  } catch (err) {
    showAlert("Erreur : " + err.message, "error");
  } finally {
    btn.classList.remove("loading");
    btn.querySelector(".btn-text").textContent = "Analyser la transaction";
  }
}

// ─── Rendu du résultat ────────────────────────────────────────────────────────
function renderResult(r) {
  const panel = $("result-content");
  panel.innerHTML = "";

  // Verdict principal
  const verdictBox = document.createElement("div");
  verdictBox.className = "verdict-box " + (r.is_fraud ? "fraud" : "legit");
  verdictBox.innerHTML = `
    <div class="verdict-icon">${r.is_fraud ? "🚨" : "✅"}</div>
    <div class="verdict-label ${r.is_fraud ? "fraud" : "legit"}">${r.prediction_label}</div>
    <span class="risk-badge risk-${r.risk_level}">
      Risque ${r.risk_level}
    </span>
  `;
  panel.appendChild(verdictBox);

  // Probabilités
  const probDiv = document.createElement("div");
  probDiv.className = "prob-row";
  probDiv.innerHTML = `
    <div class="prob-card fraud-card">
      <div class="pct">${(r.fraud_probability * 100).toFixed(1)}%</div>
      <div class="lbl">Probabilité de fraude</div>
    </div>
    <div class="prob-card legit-card">
      <div class="pct">${(r.legitimate_probability * 100).toFixed(1)}%</div>
      <div class="lbl">Probabilité légitime</div>
    </div>
  `;
  panel.appendChild(probDiv);

  // Gauge
  const gaugeDiv = document.createElement("div");
  gaugeDiv.className = "gauge-wrap";
  const pct = Math.round(r.fraud_probability * 100);
  const gaugeColor = r.fraud_probability < 0.3
    ? "#2dc653"
    : r.fraud_probability < 0.5
    ? "#f4a261"
    : r.fraud_probability < 0.75
    ? "#e65100"
    : "#e63946";
  gaugeDiv.innerHTML = `
    <div class="gauge-label">
      <span>0% — Légitime</span>
      <span>100% — Fraude</span>
    </div>
    <div class="gauge-track">
      <div class="gauge-fill" id="gauge-fill" style="width:0%;background:${gaugeColor}"></div>
    </div>
  `;
  panel.appendChild(gaugeDiv);
  // Animation jauge
  setTimeout(() => {
    const fill = $("gauge-fill");
    if (fill) fill.style.width = pct + "%";
  }, 80);

  // Top features
  if (r.top_features && r.top_features.length > 0) {
    const featTitle = document.createElement("div");
    featTitle.className = "card-title";
    featTitle.style.marginTop = "20px";
    featTitle.innerHTML = `
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
        <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
      </svg>
      Variables les plus influentes
    `;
    panel.appendChild(featTitle);

    const maxImp = r.top_features[0].importance;
    const featList = document.createElement("div");
    featList.className = "feat-list";
    r.top_features.forEach(f => {
      const pct = maxImp > 0 ? Math.round((f.importance / maxImp) * 100) : 0;
      const item = document.createElement("div");
      item.className = "feat-item";
      item.innerHTML = `
        <div class="feat-header">
          <span class="feat-name">${f.feature}</span>
          <span class="feat-val">val: ${f.value} — imp: ${(f.importance * 100).toFixed(2)}%</span>
        </div>
        <div class="feat-bar-track">
          <div class="feat-bar-fill" style="width:${pct}%"></div>
        </div>
      `;
      featList.appendChild(item);
    });
    panel.appendChild(featList);
  }
}

function hideResult() {
  const panel = $("result-content");
  panel.innerHTML = `
    <div class="placeholder-text">
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5">
        <circle cx="12" cy="12" r="10"/>
        <path d="M12 8v4m0 4h.01"/>
      </svg>
      <p>Remplissez le formulaire et cliquez sur<br><strong>Analyser la transaction</strong></p>
    </div>
  `;
}

// ─── Alertes ──────────────────────────────────────────────────────────────────
function showAlert(msg, type = "error") {
  const el = $("alert-box");
  el.className = `alert alert-${type} show`;
  el.querySelector(".alert-msg").textContent = msg;
}

function hideAlert() {
  const el = $("alert-box");
  if (el) el.classList.remove("show");
}
