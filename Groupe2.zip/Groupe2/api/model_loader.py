import os
import xgboost as xgb
import numpy as np
from pathlib import Path

# Chemin absolu vers le fichier modèle
MODEL_DIR = Path(__file__).parent.parent / "models"
MODEL_JSON_PATH = MODEL_DIR / "xgb_model.json"

FEATURE_NAMES = [
    "Time", "V1", "V2", "V3", "V4", "V5", "V6", "V7", "V8", "V9",
    "V10", "V11", "V12", "V13", "V14", "V15", "V16", "V17", "V18",
    "V19", "V20", "V21", "V22", "V23", "V24", "V25", "V26", "V27",
    "V28", "Amount"
]


def load_model():
    """Charge le modèle XGBoost depuis le fichier JSON."""
    if not MODEL_JSON_PATH.exists():
        raise FileNotFoundError(
            f"Fichier modèle introuvable : {MODEL_JSON_PATH}\n"
            f"Placez le fichier xgb_model.json dans : {MODEL_DIR}"
        )
    model = xgb.XGBClassifier()
    model.load_model(str(MODEL_JSON_PATH))
    return model


def get_feature_importances(model: xgb.XGBClassifier) -> dict:
    """Extrait les importances des features (gain normalisé)."""
    scores = model.get_booster().get_score(importance_type="gain")
    if not scores:
        return {f: 0.0 for f in FEATURE_NAMES}
    total = sum(scores.values())
    return {k: round(v / total, 4) for k, v in scores.items()}


def predict_transaction(model: xgb.XGBClassifier, features: list) -> dict:
    """
    Prédit si une transaction est frauduleuse.
    features : liste ordonnée selon FEATURE_NAMES.
    """
    X = np.array(features).reshape(1, -1)
    proba = model.predict_proba(X)[0]
    fraud_prob = float(proba[1])
    legit_prob = float(proba[0])
    is_fraud = fraud_prob >= 0.5

    if fraud_prob < 0.3:
        risk_level = "FAIBLE"
    elif fraud_prob < 0.5:
        risk_level = "MODÉRÉ"
    elif fraud_prob < 0.75:
        risk_level = "ÉLEVÉ"
    else:
        risk_level = "CRITIQUE"

    # Top features par importance globale du modèle
    importances = get_feature_importances(model)
    sorted_feats = sorted(importances.items(), key=lambda x: x[1], reverse=True)[:10]
    top_features = [
        {"feature": k, "importance": v, "value": round(features[FEATURE_NAMES.index(k)], 4)}
        for k, v in sorted_feats
        if k in FEATURE_NAMES
    ]

    return {
        "is_fraud": is_fraud,
        "fraud_probability": round(fraud_prob, 4),
        "legitimate_probability": round(legit_prob, 4),
        "risk_level": risk_level,
        "prediction_label": "FRAUDE" if is_fraud else "LÉGITIME",
        "top_features": top_features,
    }
