from fastapi import FastAPI, HTTPException
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware
from pathlib import Path
import logging

from .schemas import (
    TransactionInput, BatchTransactionInput,
    PredictionResult, BatchPredictionResult
)
from .model_loader import load_model, predict_transaction, FEATURE_NAMES

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# ── Initialisation de l'application ──────────────────────────────────────────
app = FastAPI(
    title="Benin Bank — API Détection de Fraude",
    description=(
        "API de prédiction de transactions frauduleuses basée sur un modèle "
        "XGBoost entraîné sur le dataset Credit Card Fraud Detection (Kaggle)."
    ),
    version="1.0.0",
    docs_url="/api/docs",
    redoc_url="/api/redoc",
    openapi_url="/api/openapi.json",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)

# ── Chargement du modèle au démarrage ─────────────────────────────────────────
ml_model = None

@app.on_event("startup")
async def startup_event():
    global ml_model
    try:
        ml_model = load_model()
        logger.info("Modèle XGBoost chargé avec succès.")
    except Exception as exc:
        logger.error(f"Erreur chargement modèle : {exc}")
        raise RuntimeError(f"Impossible de charger le modèle : {exc}")


# ── Montage des fichiers statiques ────────────────────────────────────────────
UI_DIR = Path(__file__).parent.parent / "ui"
STATIC_DIR = UI_DIR / "static"

if STATIC_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")


# ── Routes ────────────────────────────────────────────────────────────────────

@app.get("/", response_class=HTMLResponse, include_in_schema=False)
async def serve_ui():
    """Sert l'interface utilisateur principale."""
    index_path = UI_DIR / "index.html"
    if index_path.exists():
        return FileResponse(str(index_path))
    return HTMLResponse("<h1>Interface non trouvée. Vérifiez le dossier ui/</h1>", status_code=404)


@app.get("/api/health", tags=["Système"])
async def health_check():
    """Vérifie que l'API et le modèle sont disponibles."""
    return {
        "status": "ok",
        "model_loaded": ml_model is not None,
        "model_type": "XGBoost Classifier",
        "features_count": len(FEATURE_NAMES),
    }


@app.get("/api/model-info", tags=["Système"])
async def model_info():
    """Retourne les métadonnées du modèle."""
    if ml_model is None:
        raise HTTPException(status_code=503, detail="Modèle non chargé.")
    return {
        "model_type": "XGBoost Classifier",
        "n_features": len(FEATURE_NAMES),
        "feature_names": FEATURE_NAMES,
        "target": {"0": "Transaction légitime", "1": "Transaction frauduleuse"},
        "threshold": 0.5,
        "dataset": "Credit Card Fraud Detection — Kaggle (ULB)",
    }


@app.post("/api/predict", response_model=PredictionResult, tags=["Prédiction"])
async def predict(transaction: TransactionInput):
    """
    Prédit si une transaction bancaire est frauduleuse.

    Retourne :
    - **is_fraud** : booléen indiquant si la transaction est suspecte
    - **fraud_probability** : probabilité de fraude (0–1)
    - **risk_level** : FAIBLE / MODÉRÉ / ÉLEVÉ / CRITIQUE
    - **top_features** : variables les plus influentes du modèle
    """
    if ml_model is None:
        raise HTTPException(status_code=503, detail="Modèle non disponible.")

    features = [getattr(transaction, f) for f in FEATURE_NAMES]
    try:
        result = predict_transaction(ml_model, features)
    except Exception as exc:
        logger.error(f"Erreur lors de la prédiction : {exc}")
        raise HTTPException(status_code=500, detail=f"Erreur de prédiction : {str(exc)}")

    return PredictionResult(**result)


@app.post("/api/predict/batch", response_model=BatchPredictionResult, tags=["Prédiction"])
async def predict_batch(payload: BatchTransactionInput):
    """
    Prédit la fraude pour une liste de transactions (max 500).
    """
    if ml_model is None:
        raise HTTPException(status_code=503, detail="Modèle non disponible.")
    if len(payload.transactions) > 500:
        raise HTTPException(status_code=400, detail="Maximum 500 transactions par requête.")

    results = []
    for txn in payload.transactions:
        features = [getattr(txn, f) for f in FEATURE_NAMES]
        result = predict_transaction(ml_model, features)
        results.append(PredictionResult(**result))

    fraud_count = sum(1 for r in results if r.is_fraud)
    return BatchPredictionResult(
        results=results,
        total=len(results),
        fraud_count=fraud_count,
        legitimate_count=len(results) - fraud_count,
    )
