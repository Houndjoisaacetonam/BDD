from pydantic import BaseModel, Field
from typing import List, Optional


class TransactionInput(BaseModel):
    """Données d'une transaction bancaire à analyser."""
    Time: float = Field(..., description="Secondes écoulées depuis la première transaction")
    V1: float = Field(..., description="Composante PCA 1")
    V2: float = Field(..., description="Composante PCA 2")
    V3: float = Field(..., description="Composante PCA 3")
    V4: float = Field(..., description="Composante PCA 4")
    V5: float = Field(..., description="Composante PCA 5")
    V6: float = Field(..., description="Composante PCA 6")
    V7: float = Field(..., description="Composante PCA 7")
    V8: float = Field(..., description="Composante PCA 8")
    V9: float = Field(..., description="Composante PCA 9")
    V10: float = Field(..., description="Composante PCA 10")
    V11: float = Field(..., description="Composante PCA 11")
    V12: float = Field(..., description="Composante PCA 12")
    V13: float = Field(..., description="Composante PCA 13")
    V14: float = Field(..., description="Composante PCA 14")
    V15: float = Field(..., description="Composante PCA 15")
    V16: float = Field(..., description="Composante PCA 16")
    V17: float = Field(..., description="Composante PCA 17")
    V18: float = Field(..., description="Composante PCA 18")
    V19: float = Field(..., description="Composante PCA 19")
    V20: float = Field(..., description="Composante PCA 20")
    V21: float = Field(..., description="Composante PCA 21")
    V22: float = Field(..., description="Composante PCA 22")
    V23: float = Field(..., description="Composante PCA 23")
    V24: float = Field(..., description="Composante PCA 24")
    V25: float = Field(..., description="Composante PCA 25")
    V26: float = Field(..., description="Composante PCA 26")
    V27: float = Field(..., description="Composante PCA 27")
    V28: float = Field(..., description="Composante PCA 28")
    Amount: float = Field(..., ge=0, description="Montant de la transaction en euros")

    class Config:
        json_schema_extra = {
            "example": {
                "Time": 0.0, "V1": -1.35, "V2": -0.07, "V3": 2.53,
                "V4": 1.37, "V5": -0.33, "V6": 0.46, "V7": 0.23,
                "V8": 0.09, "V9": 0.36, "V10": 0.09, "V11": -0.55,
                "V12": -0.61, "V13": -0.99, "V14": -0.31, "V15": 1.46,
                "V16": -0.47, "V17": 0.20, "V18": 0.02, "V19": 0.40,
                "V20": 0.25, "V21": -0.01, "V22": 0.27, "V23": -0.11,
                "V24": 0.06, "V25": 0.12, "V26": 0.07, "V27": 0.03,
                "V28": 0.01, "Amount": 149.62
            }
        }


class BatchTransactionInput(BaseModel):
    """Liste de transactions à analyser."""
    transactions: List[TransactionInput]


class PredictionResult(BaseModel):
    """Résultat de prédiction pour une transaction."""
    is_fraud: bool
    fraud_probability: float
    legitimate_probability: float
    risk_level: str
    prediction_label: str
    top_features: List[dict]


class BatchPredictionResult(BaseModel):
    """Résultats de prédictions pour plusieurs transactions."""
    results: List[PredictionResult]
    total: int
    fraud_count: int
    legitimate_count: int
